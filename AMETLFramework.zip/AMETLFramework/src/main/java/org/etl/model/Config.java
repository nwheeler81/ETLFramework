package org.etl.model;

import java.util.Date;

public class Config {

  private String jobId;
  private String jobDescription;
  private String source;
  private String typeSource;
  private String target;
  private String typeTarget;
  private Date lastRun;
  private Integer coresExecutor;
  private Integer memoryExecutor;
  private Boolean active;
  private Boolean header;
  private Date createDt;
  private Date updateDt;
  private String user;

  public Config() {
    super();
  }

  public String getJobId() {
    return jobId;
  }

  public void setJobId(String jobId) {
    this.jobId = jobId;
  }

  public String getJobDescription() {
    return jobDescription;
  }

  public void setJobDescription(String jobDescription) {
    this.jobDescription = jobDescription;
  }

  public String getSource() {
    return source;
  }

  public void setSource(String source) {
    this.source = source;
  }

  public String getTypeSource() {
    return typeSource;
  }

  public void setTypeSource(String typeSource) {
    this.typeSource = typeSource;
  }

  public String getTarget() {
    return target;
  }

  public void setTarget(String target) {
    this.target = target;
  }

  public String getTypeTarget() {
    return typeTarget;
  }

  public void setTypeTarget(String typeTarget) {
    this.typeTarget = typeTarget;
  }

  public Date getLastRun() {
    return lastRun;
  }

  public void setLastRun(Date lastRun) {
    this.lastRun = lastRun;
  }

  public Integer getCoresExecutor() {
    return coresExecutor;
  }

  public void setCoresExecutor(Integer coresExecutor) {
    this.coresExecutor = coresExecutor;
  }

  public Integer getMemoryExecutor() {
    return memoryExecutor;
  }

  public void setMemoryExecutor(Integer memoryExecutor) {
    this.memoryExecutor = memoryExecutor;
  }

  public Boolean getActive() {
    return active;
  }

  public void setActive(Boolean active) {
    this.active = active;
  }

  public Boolean getHeader() {
    return header;
  }

  public void setHeader(Boolean header) {
    this.header = header;
  }

  public Date getCreateDt() {
    return createDt;
  }

  public void setCreateDt(Date createDt) {
    this.createDt = createDt;
  }

  public Date getUpdateDt() {
    return updateDt;
  }

  public void setUpdateDt(Date updateDt) {
    this.updateDt = updateDt;
  }

  public String getUser() {
    return user;
  }

  public void setUser(String user) {
    this.user = user;
  }

  @Override
  public String toString() {
    return "Config{"
        + "jobId='"
        + jobId
        + '\''
        + ", jobDescription='"
        + jobDescription
        + '\''
        + ", source='"
        + source
        + '\''
        + ", typeSource='"
        + typeSource
        + '\''
        + ", target='"
        + target
        + '\''
        + ", typeTarget='"
        + typeTarget
        + '\''
        + ", lastRun="
        + lastRun
        + ", coresExecutor="
        + coresExecutor
        + ", memoryExecutor="
        + memoryExecutor
        + ", active="
        + active
        + ", header="
        + header
        + ", createDt="
        + createDt
        + ", updateDt="
        + updateDt
        + ", user='"
        + user
        + '\''
        + '}';
  }
}
