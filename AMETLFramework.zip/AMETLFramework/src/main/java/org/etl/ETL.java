package org.etl;

import org.etl.model.Config;
import org.etl.transformation.Udf;

import org.apache.commons.cli.*;

import org.apache.spark.sql.SparkSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class ETL {

  private static Logger logger = LoggerFactory.getLogger(ETL.class);

  public static void main(String[] args)
      throws ParseException, ClassNotFoundException, NoSuchMethodException, IllegalAccessException,
          InvocationTargetException, InstantiationException {

    Options options = new Options();
    options.addOption("jobName", true, "Job name");
    options.addOption("contactPoints", true, "Cassandra contact points");

    options.addOption("login", true, "C* login");
    options.addOption("passwd", true, "C* password");

    CommandLineParser parser = new DefaultParser();
    CommandLine cmd = parser.parse(options, args);
    String jobId = cmd.getOptionValue("jobName");
    String contactPoints = cmd.getOptionValue("contactPoints");
    String login = cmd.getOptionValue("login");
    String pwd = cmd.getOptionValue("passwd");

    // Read job configuration by jobId
    ConfDao dao = new ConfDao(contactPoints.split(","), login, pwd);
    Config conf = dao.getJob(jobId);
    logger.info(conf.toString());

    // Create Spark Session
    logger.info("Creating Spark Session");
    SparkSession spark =
        SparkSession.builder()
            .appName(conf.getJobId())
            .config("spark.cores.max", conf.getCoresExecutor())
            .config("spark.executor.memory", conf.getMemoryExecutor() + "G")
            .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
            .config("spark.cassandra.output.ignoreNulls", "true")
            .getOrCreate();
    logger.info("Define UDF functions");
    // Create UDF functions
    Udf udf = new Udf(spark);

    logger.info("Run the job");
    // Run a job
    Class<?> clazz = Class.forName("org.etl.jobs." + jobId);
    Constructor<?> constructor = clazz.getConstructor(SparkSession.class, Config.class);
    Object instance = constructor.newInstance(spark, conf);

    spark.stop();

    System.exit(0);
  }
}
