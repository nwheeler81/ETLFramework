package org.etl;

import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.etl.model.Config;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import java.util.*;
import java.util.regex.Pattern;

public class CommonDao implements DataConnector {

  static StructType schemaSrc;
  SparkSession spark;
  Config etlConf;

  public CommonDao(SparkSession ss, Config cfg) {

    spark = ss;
    etlConf = cfg;

    Dataset<Row> etlMapping =
        spark.table("etl_config.etl_mapping").where("job_id==" + "'" + etlConf.getJobId() + "'");

    String schemaSource =
        etlMapping
            .select("source_column")
            .where("source_column is not null")
            .toJavaRDD()
            .map(s -> s.toString().concat(" ").replace("[", "").replace("]", ""))
            .reduce((s1, s2) -> (s1 + s2));
    String schemaSourceType =
        etlMapping
            .select("source_column_type")
            .where("source_column is not null")
            .toJavaRDD()
            .map(s -> s.toString().concat(" ").replace("[", "").replace("]", ""))
            .reduce((s1, s2) -> (s1 + s2));
    String schemaTarget =
        etlMapping
            .select("target_column")
            .where("source_column is not null")
            .toJavaRDD()
            .map(s -> s.toString().concat(" ").replace("[", "").replace("]", ""))
            .reduce((s1, s2) -> (s1 + s2));
    String schemaTargetType =
        etlMapping
            .select("target_column_type")
            .where("source_column is not null")
            .toJavaRDD()
            .map(s -> s.toString().concat(" ").replace("[", "").replace("]", ""))
            .reduce((s1, s2) -> (s1 + s2));
    Map<String, String> map = new HashMap<String, String>();

    List<String> columns = new ArrayList<>();
    for (String field : schemaSource.split(" ")) {
      columns.add(field);
    }

    List<String> types = new ArrayList<>();
    for (String typeName : schemaSourceType.split(" ")) {
      types.add(typeName);
    }

    Iterator<String> i1 = columns.iterator();
    Iterator<String> i2 = types.iterator();
    while (i1.hasNext() || i2.hasNext()) map.put(i1.next(), i2.next());

    // Generate the source schema based on the string of schema

    List<StructField> fields = new ArrayList<>();

    for (String fieldName : schemaSource.split(" ")) {
      StructField field =
          DataTypes.createStructField(fieldName, getDataType(map.get(fieldName)), true);
      fields.add(field);
    }
    /*StructType*/
    schemaSrc = DataTypes.createStructType(fields);
  }

  DataType getDataType(String dt) {
    switch (dt) {
      case "StringType":
        return DataTypes.StringType;
      case "BinaryType":
        return DataTypes.BinaryType;
      case "BooleanType":
        return DataTypes.BooleanType;
      case "DateType":
        return DataTypes.DateType;
      case "IntegerType":
        return DataTypes.IntegerType;
      case "DoubleType":
        return DataTypes.DoubleType;
      default:
        return DataTypes.StringType;
    }
  }

  // Retrieve data from source

  @Override
  public Dataset<Row> dataS3Extractor() {
    System.out.println(schemaSrc);
    return spark
        .read()
        .schema(schemaSrc)
        .option("header", etlConf.getHeader())
        .format("csv")
        .load(etlConf.getSource());
  }

  @Override
  public Dataset<Row> dataOracleExtractor() {
    Dataset<Row> jdbcDF =
        spark
            .read()
            .format("jdbc")
            .option("url", etlConf.getSource())
            .option("dbtable", etlConf.getTypeSource())
            .option("driver", "oracle.jdbc.driver.OracleDriver")
            .load();
    return jdbcDF;
  }

  @Override
  public Dataset<Row> dataFileExtractor() {
    return spark
        .read()
        .schema(schemaSrc)
        .option("header", etlConf.getHeader())
        .csv(etlConf.getSource());
  }

  // Save df to target

  @Override
  public void dataFileSaver(Dataset<Row> ds) {}

  @Override
  public void dataCassandraSaver(Dataset<Row> ds) {

    Map<String, String> opt = new HashMap<>();

    List<String> elem = new ArrayList<>();
    for (String param : etlConf.getTarget().split(Pattern.quote("."))) {
      elem.add(param);
    }
    opt.put("keyspace", elem.get(0));
    opt.put("table", elem.get(1));

    ds.write().format("org.apache.spark.sql.cassandra").mode("Append").options(opt).save();
  }
}
