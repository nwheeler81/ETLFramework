package org.etl;

import com.datastax.driver.core.*;
import org.etl.model.Config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConfDao {

  private static Logger logger = LoggerFactory.getLogger(ConfDao.class);
  private static String keyspaceName = "etl_config";
  private static String jobTable = keyspaceName + ".etl_jobs";
  private static final String GET_JOB_CONF = "select * from " + jobTable + " where job_id = ?";
  private Session session;
  private PreparedStatement getJobConf;

  public ConfDao(String[] contactPoints, String login, String pwd) {

    Cluster cluster =
        Cluster.builder().addContactPoints(contactPoints).withCredentials(login, pwd).build();

    this.session = cluster.connect();

    try {
      this.getJobConf = session.prepare(GET_JOB_CONF);

    } catch (Exception e) {
      e.printStackTrace();
      session.close();
      cluster.close();
    }
  }

  public Config getJob(String jobId) {

    ResultSetFuture rs = this.session.executeAsync(this.getJobConf.bind(jobId));

    Row row = rs.getUninterruptibly().one();
    if (row == null) {
      throw new RuntimeException("Error - no job for id:" + jobId);
    }

    return rowToConf(row);
  }

  private Config rowToConf(Row row) {

    Config conf = new Config();

    conf.setJobId(row.getString("job_id"));
    conf.setActive(row.getBool("active"));
    conf.setCoresExecutor(row.getInt("cores_executor"));
    conf.setHeader(row.getBool("header"));
    conf.setJobDescription(row.getString("job_description"));
    conf.setMemoryExecutor(row.getInt("memory_executor"));
    conf.setSource(row.getString("source"));
    conf.setTarget(row.getString("target"));
    conf.setTypeSource(row.getString("source_type"));
    conf.setTypeTarget(row.getString("target_type"));
    conf.setUser(row.getString("user"));

    return conf;
  }
}
