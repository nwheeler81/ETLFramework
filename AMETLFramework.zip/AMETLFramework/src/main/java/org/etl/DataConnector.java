package org.etl;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;

public interface DataConnector {

  Dataset<Row> dataS3Extractor();

  Dataset<Row> dataOracleExtractor();

  Dataset<Row> dataFileExtractor();

  void dataFileSaver(Dataset<Row> ds);

  void dataCassandraSaver(Dataset<Row> ds);
}
