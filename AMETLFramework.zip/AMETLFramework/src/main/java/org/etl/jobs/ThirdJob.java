package org.etl.jobs;

import org.etl.DataConnector;
import org.etl.CommonDao;
import org.etl.model.Config;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class ThirdJob {

  public ThirdJob(SparkSession spark, Config etlConf) {
    DataConnector conn = new CommonDao(spark, etlConf);
    Dataset<Row> dfSource = conn.dataS3Extractor();
    dfSource.show(false);
    System.out.println(dfSource.count());
    dfSource.printSchema();

    Dataset<Row> dfTarget = dfSource.groupBy(("type")).sum("amount");
    dfTarget.show(false);
  }
}
