package org.etl.jobs;

import org.etl.DataConnector;
import org.etl.model.Config;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;

import org.apache.spark.sql.SparkSession;

import org.etl.CommonDao;

public class FirstJob {

  public FirstJob(SparkSession spark, Config etlConf) {

    DataConnector conn = new CommonDao(spark, etlConf);
    Dataset<Row> dfSource = conn.dataFileExtractor();
    dfSource.show(false);
    System.out.println(dfSource.count());
    Dataset<Row> dfTarget = dfSource.selectExpr("*", "timeUUID(0) as id");
    dfTarget.show(false);
    System.out.println(dfTarget.count());
    conn.dataCassandraSaver(dfTarget);
  }
}
