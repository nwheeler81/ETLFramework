package org.etl.jobs;

import org.etl.DataConnector;
import org.etl.CommonDao;
import org.etl.model.Config;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class SecondJob {

  public SecondJob(SparkSession spark, Config etlConf) {
    DataConnector conn = new CommonDao(spark, etlConf);
    Dataset<Row> df = conn.dataOracleExtractor();
    df.show(false);
  }
}
