package org.etl.transformation;

import org.apache.spark.sql.api.java.UDF1;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.SparkSession;
import com.datastax.driver.core.utils.UUIDs;

import java.io.Serializable;

public class Udf implements Serializable {

  public Udf(SparkSession spark) {
    // Register User Define Functions
    spark.udf().register("strLen", (String s) -> s.length(), DataTypes.IntegerType);

    spark
        .udf()
        .register(
            "timeUUID",
            new UDF1<Integer, String>() {
              @Override
              public String call(Integer tmp) {
                return UUIDs.timeBased().toString();
              }
            },
            DataTypes.StringType);
  }
}
